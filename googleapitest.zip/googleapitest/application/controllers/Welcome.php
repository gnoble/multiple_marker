<?php
defined('BASEPATH') OR exit('No direct script access allowed');
ini_set('MAX_EXECUTION_TIME', -1);
class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct() {
        parent::__construct();
		$this->load->library('googlemaps'); 
	}
	public function index()
	{
		$data['grabapidata'] = (array)$this->grabapidata();
		$config = array();
		$config['apiKey'] = API_KEY;
		$config['animation'] = 'BOUNCE';
		$config['center'] = "33.7317075089936, -117.74036114355471";
		//echo "<pre>"; print_r($data); exit;
		//$config['zoom']= '5';
		/* make sure whene change api key it should be enable from google api 
		ref : https://console.developers.google.com/apis */
		$this->googlemaps->initialize($config);
		$marker = array();
		//$marker['infowindow_type'] ='html';
		/*$marker['clickable'] = 'TRUE';
		$marker['position'] = '1313 Collective Santa Ana';
		$marker['infowindow_content'] = '1313 Collective Santa Ana';
		$this->googlemaps->add_marker($marker); 

		$marker['clickable'] = 'TRUE';
		$marker['position'] = '1Stop  South OC';
		$marker['infowindow_content'] = '1Stop  South OC';
		$this->googlemaps->add_marker($marker); */
		/*$i=0;
		foreach ($data['grabapidata'] as $key => $value) {
			//echo $value['disp_name']; exit;
			$marker = array();
			$marker['position'] = $value['disp_name'].', '.$value['disp_city'].' '.$value['disp_state'];
			//$marker['position'] = " $value->disp_latitude , $value->disp_longitude" ;
			//$marker['lat_long'] = "$value->disp_latitude,$value->disp_longitude";
			//$marker['infowindow_type'] = 'html';
			$table = "<table>";
			$table .="<tr><td>Name</td> <td>";
			$table .= $value['disp_name'];
			$table .="</td>";
			$table .="</tr>";
			$table .="</table>";
			$marker['infowindow_content'] = $table;
			$marker['clickable'] = 'TRUE';
			$this->googlemaps->add_marker($marker); 
			$i++;
			if($i==50){break;}
		}*/
		$data['map'] = $this->googlemaps->create_map(); 
		$this->load->view('welcome_message',$data);
	}
	/* Bellow function is used to grab the api data  and its start from here here*/
	public function grabapidata()
	{
		$para = array(
                'nelat'=> '33.7317075089936',
                'nelng'=> '-117.74036114355471',
                'swlat'=> '33.58882717363751',
                'swlng'=> '-118.25809185644533',
                 );
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, API_URL);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERPWD, API_USERNAME.':'.API_PASSWORD);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($para));
        $response = curl_exec($ch);
        if(!empty($response) && isset($response)){
        	return $response = json_decode($response,true);
        }
        else{
        	return 0;
        }

	}
	public function ajaxgrabapidata()
	{
		$para = array(
                'nelat'=> '33.7317075089936',
                'nelng'=> '-117.74036114355471',
                'swlat'=> '33.58882717363751',
                'swlng'=> '-118.25809185644533',
                 );
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, API_URL);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERPWD, API_USERNAME.':'.API_PASSWORD);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($para));
        $response = curl_exec($ch);
        if(!empty($response) && isset($response)){
        	 //$response = json_decode($response,true);
        	 die($response);
        }
        else{
        	die(json_encode(0));
        }

	}
	public function details()
	{
		$id = $_REQUEST['id'];
		//$details_data = array();
		$para = array(
                'nelat'=> '33.7317075089936',
                'nelng'=> '-117.74036114355471',
                'swlat'=> '33.58882717363751',
                'swlng'=> '-118.25809185644533',
                 );
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, API_URL);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERPWD, API_USERNAME.':'.API_PASSWORD);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($para));
        $response = curl_exec($ch);
        $response = json_decode($response);
		foreach ($response as $key => $value) {
			if ($value->disp_id == $id )
			{
				$table = "<table class='table'>";
				$table .= "<tr><td>Name</td>";
				$table .= "<td>$value->disp_name</td></tr>";
				$table .= "<tr><td>Phone</td>";
				$table .= "<td>$value->disp_phone</td></tr>";
				$table .= "<tr><td>City </td>";
				$table .= "<td>$value->disp_city</td></tr>";
				$table .= "<tr><td>State </td>";
				$table .= "<td>$value->disp_state</td></tr>";
				$table .= "<tr><td>Type </td>";
				$table .= "<td>$value->disp_type</td></tr>";
				$table .= "<tr><td>Store Type </td>";
				$table .= "<td>$value->disp_store_type</td></tr>";
				$table .= "<tr><td>1 GM </td>";
				$table .= "<td>$value->disp_price_1_gm</td></tr>";
				//$table .= "<tr><td>1/8 oz</td>";
				//$table .= "<td>$value->disp_price_1/8_oz</td></tr>";
				//$table .= "<tr><td>1/4 oz</td>";
				//$table .= "<td>$value->disp_price_1/4_oz</td></tr>";
				//$table .= "<tr><td>1/2 oz</td>";
				//$table .= "<td>$value->disp_price_1/2_oz</td></tr>";
				$table .= "<tr><td>1 oz</td>";
				$table .= "<td>$value->disp_price_1_oz</td></tr>";
				$table .="</table>";

				echo $table; exit;
			}
		}
	}
}
