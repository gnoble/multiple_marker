$(document).ready(function() {
     
$( window ).on( "load", function() {
          var price ='';
            var price_text ='';
            price = $('#fil_weights :selected').val();
            price_text = $('#fil_weights :selected').text(); 
$.ajax({
          url: '/googleapitest/index.php/welcome/ajaxgrabapidata',
          type: "POST",
          data : '',
          dataType: "json", //retrieved Markers Lat/lng in Json, thus using this dataType
          success: function(data){
            //console.log(data);
            //Removing already Added Markers//////////
                for(var i=0; i < markers_map.length; i++){
                    markers_map[i].setMap(null);
                }
                markers_map = new Array();
                marker = new Array();
            //////////////////////////////////////////
            // Adding New Markers////////////////////
             
                for (var i = 0, len = data.length; i < len; ++i) { // Iterating the Json Array
                    var d = data[i];
                    
                    var lat = parseFloat(d.disp_latitude);
                    var lng = parseFloat(d.disp_longitude);  
                    var myLatlng = new google.maps.LatLng(lat,lng);
                    //infowindow = new google.maps.InfoWindow();
                    var markerOptions  = {
                        map:map,
                        position:myLatlng, // These are the minimal Options, you can add others too
                        infowindow_type: 'html',
                        clickable:true,
                        title: d.disp_name,
                        //infowindow_content:d.disp_name

                    };
                   if(price == 'disp_price_1_gm'){ var price_set = d.disp_price_1_gm ; console.log(price_set);}
                   //else if(price == "disp_price_1/2_oz"){ price = d.disp_price_1/2_oz ;}
                   //else if(price == "disp_price_1/4_oz"){ price = d.disp_price_1/4_oz;}
                   //else if(price == "disp_price_1/8_oz"){ price = d.disp_price_1/8_oz;}
                   else if(price == "disp_price_1_oz"){ var price_set = d.disp_price_1_oz ; console.log(price_set);}
                   else { var price_set = 'N/A'; console.log(price_set);}
                   
                    var marker_content = "<div class='col-lg-4'><b>Name : "+d.disp_name+"</b></div>";
                     marker_content = marker_content + "<div class='col-lg-4'><b>City : "+d.disp_city+"</b></div>";
                     marker_content = marker_content + "<div class='col-lg-4'><b>State : "+d.disp_state+"</b></div>";
                     marker_content = marker_content + "<div class='col-lg-4'><b>Store Type : "+d.disp_store_type+"</b></div>";
                     marker_content = marker_content + "<div class='col-lg-4'><b>Price "+price_text+" : "+price_set+"</b></div>";
                     marker_content = marker_content + "<div class='col-lg-4'><a href='javascript:void(0);'><div id='details_id' id-data='"+d.disp_id+"'>Go To Details </div></a></div></div>";
                    marker[i]  = createMarker_map(markerOptions);
                    marker[i].set("content", marker_content);
                    google.maps.event.addListener(marker[i], "click", function(event) {
                        iw_map.setContent(this.get("content"));
                        iw_map.open(map, this);
                    });
                }
            }
          
       }
    );
});

$(document.body).on('change','#fil_weights',function(){
    $(window).trigger('load'); 
 }); 
$(document.body).on('click','#details_id',function(){
    var id = $(this).attr('id-data');
     $.ajax({
                        url:'http://localhost/googleapitest/index.php/welcome/details',
                        type: "post",
                        data:{  id: id  },
                        success: function (data) {
                            //var resp =  $.parseJSON(data);
                            $('#my-modal').modal('show');
                            $('#details_data').html('');
                            $('#details_data').html('<pre>'+data+'</pre>');
                            return false;
                        }
                   });
});
});